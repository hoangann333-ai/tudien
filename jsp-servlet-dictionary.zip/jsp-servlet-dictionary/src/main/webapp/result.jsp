<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Kết quả tra cứu</title>
  <style>
    * { box-sizing: border-box; }
    body { min-height: 100vh; margin: 0; display: grid; place-items: center; padding: 22px;
           background: #f3f6fb; color: #18233a; font-family: Arial, sans-serif; }
    main { width: min(480px, 100%); padding: 38px; border-radius: 16px; background: white;
           box-shadow: 0 16px 45px #172b4d16; text-align: center; }
    .success { color: #16804a; }
    .error { color: #c62828; }
    .notice { color: #a46800; }
    h1 { font-size: 24px; }
    p { font-size: 17px; line-height: 1.6; overflow-wrap: anywhere; }
    a { display: inline-block; margin-top: 15px; padding: 11px 18px; border-radius: 8px;
        background: #294b9c; color: white; font-weight: 700; text-decoration: none; }
  </style>
</head>
<body>
  <main>
    <h1 class="${requestScope.resultClass}">${requestScope.heading}</h1>
    <p>${requestScope.message}</p>
    <a href="${pageContext.request.contextPath}/">Tra từ khác</a>
  </main>
</body>
</html>
