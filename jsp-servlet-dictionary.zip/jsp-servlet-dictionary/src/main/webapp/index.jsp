<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Từ điển Anh – Việt</title>
  <style>
    * { box-sizing: border-box; }
    body {
      min-height: 100vh; margin: 0; display: grid; place-items: center; padding: 22px;
      color: #17243b; font-family: Arial, Helvetica, sans-serif;
      background: linear-gradient(135deg, #edf3ff, #f8faff 55%, #e8f0ff);
    }
    .dictionary-card {
      width: min(480px, 100%); padding: 38px; border: 1px solid #e5eaf3;
      border-radius: 18px; background: #fff; box-shadow: 0 18px 55px #223a6418;
    }
    .brand {
      width: 48px; height: 48px; display: grid; place-items: center; margin-bottom: 22px;
      border-radius: 14px; background: #eaf0ff; color: #3556a5; font-size: 22px; font-weight: 800;
    }
    h1 { margin: 0 0 9px; font-size: 27px; }
    .intro { margin: 0 0 25px; color: #718097; font-size: 14px; line-height: 1.6; }
    label { display: block; margin-bottom: 8px; font-size: 13px; font-weight: 700; }
    input {
      width: 100%; height: 48px; padding: 0 14px; border: 1px solid #d9e0ec;
      border-radius: 9px; outline: none; font: inherit;
    }
    input:focus { border-color: #5576d8; box-shadow: 0 0 0 3px #5576d81a; }
    button {
      width: 100%; height: 47px; margin-top: 14px; border: 0; border-radius: 9px;
      background: #294b9c; color: #fff; font-size: 15px; font-weight: 700; cursor: pointer;
    }
    button:hover { background: #1c397e; }
    .examples { margin: 19px 0 0; color: #8992a3; font-size: 12px; line-height: 1.7; }
    .examples strong { color: #69758c; }
    @media (max-width: 480px) { .dictionary-card { padding: 28px 23px; } }
  </style>
</head>
<body>
  <main class="dictionary-card">
    <div class="brand" aria-hidden="true">A–V</div>
    <h1>Từ điển Anh – Việt</h1>
    <p class="intro">Nhập từ tiếng Anh bạn muốn tra cứu. Kết quả sẽ hiển thị bằng tiếng Việt.</p>
    <form action="${pageContext.request.contextPath}/translate" method="post">
      <label for="word">Từ tiếng Anh</label>
      <input id="word" name="word" type="text" placeholder="Ví dụ: hello" autocomplete="off" required autofocus>
      <button type="submit">Tìm kiếm</button>
    </form>
    <p class="examples"><strong>Từ có sẵn:</strong> hello, how, book, computer, student, school, apple, beautiful.</p>
  </main>
</body>
</html>
