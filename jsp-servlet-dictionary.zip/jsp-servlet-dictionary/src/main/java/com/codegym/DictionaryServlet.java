package com.codegym;

import java.io.IOException;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "DictionaryServlet", urlPatterns = "/translate")
public class DictionaryServlet extends HttpServlet {
    private static final Map<String, String> DICTIONARY = Map.ofEntries(
            Map.entry("hello", "Xin chào"),
            Map.entry("how", "Thế nào"),
            Map.entry("book", "Quyển sách"),
            Map.entry("computer", "Máy tính"),
            Map.entry("student", "Sinh viên"),
            Map.entry("school", "Trường học"),
            Map.entry("apple", "Quả táo"),
            Map.entry("beautiful", "Đẹp")
    );

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String word = request.getParameter("word");
        String normalizedWord = word == null ? "" : word.trim().toLowerCase();
        String meaning = DICTIONARY.get(normalizedWord);
        String contextPath = request.getContextPath();

        String heading;
        String message;
        String resultClass;

        if (normalizedWord.isBlank()) {
            heading = "Bạn chưa nhập từ";
            message = "Vui lòng nhập một từ tiếng Anh để tra cứu.";
            resultClass = "notice";
        } else if (meaning != null) {
            heading = "Kết quả tra cứu";
            message = escapeHtml(normalizedWord) + " — " + escapeHtml(meaning);
            resultClass = "success";
        } else {
            heading = "Không tìm thấy";
            message = "Không tìm thấy từ: " + escapeHtml(word.trim());
            resultClass = "error";
        }

        request.setAttribute("heading", heading);
        request.setAttribute("message", message);
        request.setAttribute("resultClass", resultClass);
        request.setAttribute("contextPath", contextPath);
        request.getRequestDispatcher("/result.jsp").forward(request, response);
    }

    private static String escapeHtml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
}
