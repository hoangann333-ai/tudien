# Từ điển Anh – Việt bằng JSP/Servlet

Dự án Maven Web App tương thích Jakarta Servlet 6.0 và Apache Tomcat 10.1+.

## Yêu cầu
- JDK 17+
- Apache Maven
- Apache Tomcat 10.1+

## Đóng gói
Mở terminal ở thư mục dự án và chạy:

```bash
mvn clean package
```

WAR được tạo tại `target/jsp-servlet-dictionary.war`.

## Chạy trên Tomcat
Chép WAR vào thư mục `webapps` của Tomcat, khởi động máy chủ rồi truy cập:

```
http://localhost:8080/jsp-servlet-dictionary/
```

Từ mẫu để thử: `hello`, `book`, `computer`, `student`. Có thể nhập chữ hoa hoặc chữ thường. Từ không có trong Map sẽ hiển thị thông báo không tìm thấy.
